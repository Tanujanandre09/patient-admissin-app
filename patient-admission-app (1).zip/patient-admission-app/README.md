# Ward Register – Patient Admission Management App

A web app for hospital staff to manage admitted patients: add, view, search, filter, edit, discharge and delete patient records. Works on mobile, tablet and desktop.

**Live app:** _ADD YOUR FRONTEND LINK HERE_
**Live API:** _ADD YOUR BACKEND LINK HERE_ (interactive API docs at `/docs`)

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18 (Vite), plain CSS (no UI library) |
| Backend | Python 3.12, FastAPI, Pydantic (validation), SQLAlchemy (ORM) |
| Database | PostgreSQL in production (data survives restarts); SQLite file for local development |
| Hosting | Frontend on Vercel, backend on Render, database on Neon |

## Features

1. Add a patient
2. View all patients (table on desktop, cards on mobile)
3. Filter by ward, department and doctor (plus status); filters combine
4. Search patients by name (case-insensitive, partial match)
5. Edit a patient
6. Delete a patient, with a confirmation dialog
7. Mark a patient as discharged, with a confirmation dialog
8. Responsive design for mobile, tablet and desktop

## Validation (frontend and backend)

The same rules run in the browser (`frontend/src/validation.js`) for instant feedback and on the server (`backend/schemas.py`), which never trusts the client.

| Field | Rule |
|---|---|
| Name | Required; letters only (single spaces between words allowed, e.g. "Ravi Kumar") |
| Age | Required; whole number from 0 to 120 |
| Gender, Ward, Department, Doctor | Required; must be one of the allowed values |
| Admission date | Required; cannot be in the future (checked in India time, IST) |

The select lists live only in `backend/constants.py` and the frontend loads them from `GET /api/options`, so both sides always agree.

Invalid data is rejected with HTTP 400 and a clear message per field:

```json
{
  "detail": "Please fix the highlighted fields.",
  "errors": {
    "name": "Name can contain letters only (spaces between words are allowed)",
    "age": "Age must be between 0 and 120",
    "admission_date": "Admission date cannot be in the future"
  }
}
```

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/options` | Lists for gender, ward, department, doctor, status |
| GET | `/api/patients?search=&ward=&department=&doctor=&status=` | List patients (all filters optional) |
| GET | `/api/patients/{id}` | One patient |
| POST | `/api/patients` | Add a patient |
| PUT | `/api/patients/{id}` | Edit a patient |
| PATCH | `/api/patients/{id}/discharge` | Mark as discharged |
| DELETE | `/api/patients/{id}` | Delete a patient |
| GET | `/api/health` | Health check |

## Project structure

```
backend/
  main.py          API routes and error handling
  schemas.py       Validation rules (Pydantic)
  models.py        Database table (SQLAlchemy)
  database.py      DB connection (DATABASE_URL or local SQLite)
  constants.py     Select-list values
  test_api.py      API tests
frontend/
  src/App.jsx              Page state, loading, dialogs
  src/api.js               All backend calls
  src/validation.js        Frontend validation rules
  src/components/          PatientForm, PatientList, Filters, Modal, ConfirmDialog
  src/styles.css           Responsive styles
```

## Run locally

Prerequisites: Python 3.10+ and Node.js 18+ (Node is only used to build the React frontend; the backend is Python).

**1. Backend**

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API runs at http://localhost:8000 (docs at http://localhost:8000/docs). Without `DATABASE_URL` it saves to `backend/patients.db`, which persists across restarts.

**2. Frontend** (new terminal)

```bash
cd frontend
npm install
cp .env.example .env            # sets VITE_API_URL=http://localhost:8000
npm run dev
```

Open http://localhost:5173.

**3. Tests (optional)**

```bash
cd backend
pip install pytest httpx
python -m pytest -q
```

## Deployment

1. **Database (Neon):** create a free project at neon.tech and copy the connection string.
2. **Backend (Render):** New → Web Service → connect this repo. Root directory `backend`, build `pip install -r requirements.txt`, start `uvicorn main:app --host 0.0.0.0 --port $PORT`. Add environment variables `DATABASE_URL` (Neon string), `ALLOWED_ORIGINS` (your Vercel URL, no trailing slash) and `PYTHON_VERSION` = `3.12.7`. `render.yaml` contains the same settings.
3. **Frontend (Vercel):** import the repo, root directory `frontend`, framework Vite. Add `VITE_API_URL` = your Render backend URL, then deploy.

Secrets are set only in the hosting dashboards; `.env` files are git-ignored and no keys are committed.

Note: Render's free tier sleeps after inactivity, so the first request can take up to a minute.

## Screenshots

| Desktop | Mobile |
|---|---|
| ![Desktop](docs/screenshots/desktop.png) | ![Mobile](docs/screenshots/mobile.png) |

| Tablet | Validation errors | Delete confirmation |
|---|---|---|
| ![Tablet](docs/screenshots/tablet.png) | ![Validation](docs/screenshots/validation.png) | ![Delete](docs/screenshots/delete-confirm.png) |
