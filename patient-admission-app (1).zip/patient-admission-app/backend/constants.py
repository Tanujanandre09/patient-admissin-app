"""Fixed lists used by the select fields.

The frontend loads these from GET /api/options, so the backend is the single
source of truth: change a list here and both sides stay in sync.
"""

GENDERS = ["Male", "Female", "Other"]

WARDS = [
    "General Ward A",
    "General Ward B",
    "ICU",
    "Pediatric Ward",
    "Maternity Ward",
    "Surgical Ward",
]

DEPARTMENTS = [
    "General Medicine",
    "Cardiology",
    "Orthopedics",
    "Neurology",
    "Pediatrics",
    "Gynecology",
    "General Surgery",
]

DOCTORS = [
    "Dr. Anjali Mehta",
    "Dr. Rahul Verma",
    "Dr. Sneha Iyer",
    "Dr. Vikram Rao",
    "Dr. Priya Nair",
    "Dr. Arjun Kapoor",
]

STATUSES = ["Admitted", "Discharged"]

# Hospital runs on Indian time; "today" for the future-date check uses IST,
# not the server's clock (cloud servers usually run on UTC).
HOSPITAL_TIMEZONE = "Asia/Kolkata"
