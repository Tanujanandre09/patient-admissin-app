"""Patient Admission Management API (FastAPI + SQLAlchemy).

Run locally:  uvicorn main:app --reload
API docs:     http://localhost:8000/docs
"""
import os
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from constants import DEPARTMENTS, DOCTORS, GENDERS, STATUSES, WARDS
from database import Base, engine, get_db
from models import Patient
from schemas import PatientIn, PatientOut

# Create the table on startup if it doesn't exist yet.
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Patient Admission Management API", version="1.0.0")

# Comma-separated list of allowed frontend URLs, e.g.
# ALLOWED_ORIGINS=https://my-app.vercel.app,http://localhost:5173
allowed_origins = [
    o.strip()
    for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",")
    if o.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

FIELD_LABELS = {
    "name": "Name",
    "age": "Age",
    "gender": "Gender",
    "ward": "Ward",
    "department": "Department",
    "doctor": "Doctor",
    "admission_date": "Admission date",
    "status": "Status",
}


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    """Turn Pydantic's verbose errors into one clear message per field.

    Response shape (HTTP 400):
    {"detail": "Please fix the highlighted fields.",
     "errors": {"age": "Age must be between 0 and 120"}}
    """
    errors: dict[str, str] = {}
    for err in exc.errors():
        loc = [str(part) for part in err.get("loc", []) if part != "body"]
        field = loc[0] if loc else "body"
        label = FIELD_LABELS.get(field, field)
        kind = err.get("type", "")

        if kind == "missing":
            message = f"{label} is required"
        elif kind == "json_invalid":
            field, message = "body", "Request body must be valid JSON"
        elif field == "admission_date" and kind.startswith("date"):
            message = "Admission date must be a valid date (YYYY-MM-DD)"
        elif kind == "value_error":
            message = err.get("msg", "").removeprefix("Value error, ")
        elif kind == "model_attributes_type" or field == "body":
            field, message = "body", "Request body must be a JSON object with patient details"
        else:
            message = f"{label} is invalid"

        errors.setdefault(field, message)

    return JSONResponse(
        status_code=400,
        content={"detail": "Please fix the highlighted fields.", "errors": errors},
    )


def get_patient_or_404(patient_id: int, db: Session) -> Patient:
    patient = db.get(Patient, patient_id)
    if patient is None:
        raise HTTPException(status_code=404, detail=f"Patient with id {patient_id} not found")
    return patient


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/options")
def get_options():
    """Lists for every select field, so the frontend never hardcodes them."""
    return {
        "genders": GENDERS,
        "wards": WARDS,
        "departments": DEPARTMENTS,
        "doctors": DOCTORS,
        "statuses": STATUSES,
    }


@app.get("/api/patients", response_model=list[PatientOut])
def list_patients(
    search: Optional[str] = None,
    ward: Optional[str] = None,
    department: Optional[str] = None,
    doctor: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """List patients, newest admission first. All filters are optional and combine."""
    query = select(Patient)
    if search and search.strip():
        query = query.where(Patient.name.ilike(f"%{search.strip()}%"))
    if ward:
        query = query.where(Patient.ward == ward)
    if department:
        query = query.where(Patient.department == department)
    if doctor:
        query = query.where(Patient.doctor == doctor)
    if status:
        query = query.where(Patient.status == status)
    query = query.order_by(Patient.admission_date.desc(), Patient.id.desc())
    return db.scalars(query).all()


@app.get("/api/patients/{patient_id}", response_model=PatientOut)
def get_patient(patient_id: int, db: Session = Depends(get_db)):
    return get_patient_or_404(patient_id, db)


@app.post("/api/patients", response_model=PatientOut, status_code=201)
def create_patient(data: PatientIn, db: Session = Depends(get_db)):
    patient = Patient(**data.model_dump())
    db.add(patient)
    db.commit()
    db.refresh(patient)
    return patient


@app.put("/api/patients/{patient_id}", response_model=PatientOut)
def update_patient(patient_id: int, data: PatientIn, db: Session = Depends(get_db)):
    patient = get_patient_or_404(patient_id, db)
    for key, value in data.model_dump().items():
        setattr(patient, key, value)
    db.commit()
    db.refresh(patient)
    return patient


@app.patch("/api/patients/{patient_id}/discharge", response_model=PatientOut)
def discharge_patient(patient_id: int, db: Session = Depends(get_db)):
    patient = get_patient_or_404(patient_id, db)
    if patient.status == "Discharged":
        raise HTTPException(status_code=400, detail="Patient is already discharged")
    patient.status = "Discharged"
    db.commit()
    db.refresh(patient)
    return patient


@app.delete("/api/patients/{patient_id}")
def delete_patient(patient_id: int, db: Session = Depends(get_db)):
    patient = get_patient_or_404(patient_id, db)
    db.delete(patient)
    db.commit()
    return {"detail": f"Patient {patient.name} deleted"}
