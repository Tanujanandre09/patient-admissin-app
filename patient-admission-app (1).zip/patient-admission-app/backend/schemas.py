"""Request/response shapes and backend validation rules.

Every rule here mirrors the frontend rules in frontend/src/validation.js.
The backend never trusts the frontend: these run on every create/update.
"""
import re
from datetime import date, datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, field_validator

from constants import DEPARTMENTS, DOCTORS, GENDERS, HOSPITAL_TIMEZONE, STATUSES, WARDS

# Letters only; single spaces allowed between words (e.g. "Ravi Kumar").
NAME_PATTERN = re.compile(r"^[A-Za-z]+( [A-Za-z]+)*$")


def today_in_hospital() -> date:
    return datetime.now(ZoneInfo(HOSPITAL_TIMEZONE)).date()


def _check_choice(value: str, allowed: list[str], label: str) -> str:
    if value is None or str(value).strip() == "":
        raise ValueError(f"{label} is required")
    if value not in allowed:
        raise ValueError(f"{label} must be one of: {', '.join(allowed)}")
    return value


class PatientIn(BaseModel):
    """Data the client sends when adding or editing a patient."""

    name: str
    age: int
    gender: str
    ward: str
    department: str
    doctor: str
    admission_date: date
    status: str = "Admitted"

    @field_validator("name", mode="before")
    @classmethod
    def validate_name(cls, v):
        if v is None or str(v).strip() == "":
            raise ValueError("Name is required")
        v = " ".join(str(v).split())  # trim and collapse extra spaces
        if not NAME_PATTERN.match(v):
            raise ValueError("Name can contain letters only (spaces between words are allowed)")
        if len(v) > 100:
            raise ValueError("Name must be 100 characters or fewer")
        return v

    @field_validator("age", mode="before")
    @classmethod
    def validate_age(cls, v):
        if v is None or str(v).strip() == "":
            raise ValueError("Age is required")
        # Reject booleans and decimals like 25.5 instead of silently converting them
        if isinstance(v, bool):
            raise ValueError("Age must be a whole number")
        try:
            number = float(v)
        except (TypeError, ValueError):
            raise ValueError("Age must be a number")
        if not number.is_integer():
            raise ValueError("Age must be a whole number")
        number = int(number)
        if number < 0 or number > 120:
            raise ValueError("Age must be between 0 and 120")
        return number

    @field_validator("gender", mode="before")
    @classmethod
    def validate_gender(cls, v):
        return _check_choice(v, GENDERS, "Gender")

    @field_validator("ward", mode="before")
    @classmethod
    def validate_ward(cls, v):
        return _check_choice(v, WARDS, "Ward")

    @field_validator("department", mode="before")
    @classmethod
    def validate_department(cls, v):
        return _check_choice(v, DEPARTMENTS, "Department")

    @field_validator("doctor", mode="before")
    @classmethod
    def validate_doctor(cls, v):
        return _check_choice(v, DOCTORS, "Doctor")

    @field_validator("admission_date", mode="before")
    @classmethod
    def validate_admission_date_present(cls, v):
        if v is None or str(v).strip() == "":
            raise ValueError("Admission date is required")
        return v

    @field_validator("admission_date")
    @classmethod
    def validate_admission_date_not_future(cls, v: date):
        if v > today_in_hospital():
            raise ValueError("Admission date cannot be in the future")
        return v

    @field_validator("status", mode="before")
    @classmethod
    def validate_status(cls, v):
        if v is None or str(v).strip() == "":
            return "Admitted"
        return _check_choice(v, STATUSES, "Status")


class PatientOut(PatientIn):
    """Data the API returns."""

    model_config = ConfigDict(from_attributes=True)

    id: int

    # Stored rows are already valid; skip the future-date check on the way out.
    @field_validator("admission_date")
    @classmethod
    def validate_admission_date_not_future(cls, v: date):
        return v
