"""Basic API tests. Run with:  python -m pytest -q   (uses a throwaway SQLite DB)"""
import os
from datetime import timedelta

os.environ["DATABASE_URL"] = "sqlite:///./test_patients.db"

from fastapi.testclient import TestClient  # noqa: E402

from main import app  # noqa: E402
from schemas import today_in_hospital  # noqa: E402

client = TestClient(app)

VALID = {
    "name": "Ravi Kumar",
    "age": 45,
    "gender": "Male",
    "ward": "ICU",
    "department": "Cardiology",
    "doctor": "Dr. Rahul Verma",
    "admission_date": str(today_in_hospital()),
}


def test_full_flow():
    r = client.post("/api/patients", json=VALID)
    assert r.status_code == 201, r.text
    pid = r.json()["id"]
    assert r.json()["status"] == "Admitted"

    assert any(p["id"] == pid for p in client.get("/api/patients", params={"search": "ravi"}).json())
    assert client.get("/api/patients", params={"ward": "ICU", "doctor": "Dr. Rahul Verma"}).status_code == 200

    r = client.put(f"/api/patients/{pid}", json={**VALID, "age": 46})
    assert r.json()["age"] == 46

    r = client.patch(f"/api/patients/{pid}/discharge")
    assert r.json()["status"] == "Discharged"
    assert client.patch(f"/api/patients/{pid}/discharge").status_code == 400

    assert client.delete(f"/api/patients/{pid}").status_code == 200
    assert client.get(f"/api/patients/{pid}").status_code == 404


def test_validation():
    cases = {
        "name": ["", "R4vi", "Ravi@"],
        "age": [-1, 121, "abc", 25.5, ""],
        "gender": ["Robot", ""],
        "ward": ["Ward Z"],
        "department": [""],
        "doctor": ["Dr. Nobody"],
        "admission_date": [str(today_in_hospital() + timedelta(days=1)), "not-a-date", ""],
    }
    for field, bad_values in cases.items():
        for bad in bad_values:
            r = client.post("/api/patients", json={**VALID, field: bad})
            assert r.status_code == 400, (field, bad, r.text)
            assert field in r.json()["errors"], (field, bad, r.json())

    payload = dict(VALID)
    del payload["name"]
    r = client.post("/api/patients", json=payload)
    assert r.json()["errors"]["name"] == "Name is required"
