import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import ConfirmDialog from "./components/ConfirmDialog.jsx";
import Filters from "./components/Filters.jsx";
import Modal from "./components/Modal.jsx";
import PatientForm from "./components/PatientForm.jsx";
import PatientList from "./components/PatientList.jsx";

const NO_FILTERS = { search: "", ward: "", department: "", doctor: "", status: "" };

export default function App() {
  const [options, setOptions] = useState(null);
  const [patients, setPatients] = useState([]);
  const [filters, setFilters] = useState(NO_FILTERS);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  const [formPatient, setFormPatient] = useState(undefined); // undefined = closed, null = add, object = edit
  const [confirm, setConfirm] = useState(null); // { kind: "delete" | "discharge", patient }
  const [confirmBusy, setConfirmBusy] = useState(false);
  const [toast, setToast] = useState(null);

  const latestRequest = useRef(0);

  const showToast = (message, tone = "ok") => {
    setToast({ message, tone, key: Date.now() });
  };

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  const loadPatients = useCallback(async (activeFilters) => {
    const requestId = ++latestRequest.current;
    setLoading(true);
    try {
      const data = await api.listPatients(activeFilters);
      if (requestId === latestRequest.current) {
        setPatients(data);
        setLoadError("");
      }
    } catch (err) {
      if (requestId === latestRequest.current) setLoadError(err.message);
    } finally {
      if (requestId === latestRequest.current) setLoading(false);
    }
  }, []);

  // Load select lists once
  useEffect(() => {
    api.getOptions().then(setOptions).catch((err) => setLoadError(err.message));
  }, []);

  // Reload whenever filters change; wait 300 ms after typing in search
  useEffect(() => {
    const t = setTimeout(() => loadPatients(filters), 300);
    return () => clearTimeout(t);
  }, [filters, loadPatients]);

  const handleSave = async (data) => {
    if (formPatient) {
      await api.updatePatient(formPatient.id, data);
      showToast(`Saved changes for ${data.name}`);
    } else {
      await api.createPatient(data);
      showToast(`Added ${data.name}`);
    }
    setFormPatient(undefined);
    loadPatients(filters);
  };

  const handleConfirm = async () => {
    const { kind, patient } = confirm;
    setConfirmBusy(true);
    try {
      if (kind === "delete") {
        await api.deletePatient(patient.id);
        showToast(`Deleted ${patient.name}`);
      } else {
        await api.dischargePatient(patient.id);
        showToast(`Discharged ${patient.name}`);
      }
      setConfirm(null);
      loadPatients(filters);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setConfirmBusy(false);
    }
  };

  const admittedCount = patients.filter((p) => p.status === "Admitted").length;
  const filtersActive = Object.values(filters).some(Boolean);

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar-inner">
          <div>
            <h1 className="title">Ward Register</h1>
            <p className="subtitle">Admitted patients across all wards</p>
          </div>
          <button type="button" className="btn btn-primary" onClick={() => setFormPatient(null)} disabled={!options}>
            Add patient
          </button>
        </div>
      </header>

      <main className="content">
        {options && (
          <Filters filters={filters} options={options} onChange={setFilters} onClear={() => setFilters(NO_FILTERS)} />
        )}

        {loadError ? (
          <div className="state state-error" role="alert">
            <p>{loadError}</p>
            <button type="button" className="btn btn-outline" onClick={() => window.location.reload()}>
              Try again
            </button>
          </div>
        ) : (
          <>
            <p className="summary" aria-live="polite">
              {loading
                ? "Loading patients…"
                : `${patients.length} ${patients.length === 1 ? "patient" : "patients"} shown, ${admittedCount} currently admitted`}
            </p>

            {!loading && patients.length === 0 ? (
              <div className="state">
                {filtersActive ? (
                  <>
                    <p>No patients match these filters.</p>
                    <button type="button" className="btn btn-outline" onClick={() => setFilters(NO_FILTERS)}>
                      Clear filters
                    </button>
                  </>
                ) : (
                  <>
                    <p>No patients yet. Add the first admission to start the register.</p>
                    <button type="button" className="btn btn-primary" onClick={() => setFormPatient(null)} disabled={!options}>
                      Add patient
                    </button>
                  </>
                )}
              </div>
            ) : (
              <PatientList
                patients={patients}
                onEdit={(p) => setFormPatient(p)}
                onDelete={(p) => setConfirm({ kind: "delete", patient: p })}
                onDischarge={(p) => setConfirm({ kind: "discharge", patient: p })}
              />
            )}
          </>
        )}
      </main>

      {options && (
        <Modal
          open={formPatient !== undefined}
          onClose={() => setFormPatient(undefined)}
          title={formPatient ? `Edit ${formPatient.name}` : "Add patient"}
        >
          <PatientForm
            key={formPatient?.id ?? "new"}
            patient={formPatient}
            options={options}
            onSubmit={handleSave}
            onCancel={() => setFormPatient(undefined)}
          />
        </Modal>
      )}

      <ConfirmDialog
        open={Boolean(confirm)}
        busy={confirmBusy}
        title={confirm?.kind === "delete" ? "Delete patient?" : "Discharge patient?"}
        message={
          confirm?.kind === "delete"
            ? `${confirm?.patient.name}'s record will be permanently removed. This can't be undone.`
            : `${confirm?.patient.name} will be marked as discharged.`
        }
        confirmLabel={confirm?.kind === "delete" ? "Delete" : "Discharge"}
        tone={confirm?.kind === "delete" ? "danger" : "primary"}
        onConfirm={handleConfirm}
        onCancel={() => setConfirm(null)}
      />

      {toast && (
        <div key={toast.key} className={`toast toast-${toast.tone}`} role="status">
          {toast.message}
        </div>
      )}
    </div>
  );
}
