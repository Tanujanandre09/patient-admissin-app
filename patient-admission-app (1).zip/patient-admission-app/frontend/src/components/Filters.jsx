export default function Filters({ filters, options, onChange, onClear }) {
  const set = (key) => (e) => onChange({ ...filters, [key]: e.target.value });
  const active = Object.values(filters).some(Boolean);

  const select = (key, label, list) => (
    <label className="filter">
      <span className="filter-label">{label}</span>
      <select value={filters[key]} onChange={set(key)}>
        <option value="">All</option>
        {list.map((item) => (
          <option key={item} value={item}>{item}</option>
        ))}
      </select>
    </label>
  );

  return (
    <section className="filters" aria-label="Search and filter patients">
      <label className="filter filter-search">
        <span className="filter-label">Search by name</span>
        <input type="search" value={filters.search} onChange={set("search")} placeholder="Type a patient name" />
      </label>
      {select("ward", "Ward", options.wards)}
      {select("department", "Department", options.departments)}
      {select("doctor", "Doctor", options.doctors)}
      {select("status", "Status", options.statuses)}
      <button type="button" className="btn btn-quiet btn-clear" onClick={onClear} disabled={!active}>
        Clear filters
      </button>
    </section>
  );
}
