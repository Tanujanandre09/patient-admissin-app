import { useEffect, useRef } from "react";

// Thin wrapper around the native <dialog> element: it gives us focus
// trapping and Escape-to-close for free.
export default function Modal({ open, onClose, title, children, size = "md" }) {
  const ref = useRef(null);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className={`modal modal-${size}`}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === ref.current) onClose(); // click on backdrop
      }}
      aria-labelledby="modal-title"
    >
      {open && (
        <div className="modal-body">
          <h2 id="modal-title" className="modal-title">{title}</h2>
          {children}
        </div>
      )}
    </dialog>
  );
}
