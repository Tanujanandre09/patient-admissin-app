import { useState } from "react";
import { ApiError } from "../api.js";
import { todayIST, validatePatient } from "../validation.js";

const EMPTY = {
  name: "",
  age: "",
  gender: "",
  ward: "",
  department: "",
  doctor: "",
  admission_date: "",
  status: "Admitted",
};

export default function PatientForm({ patient, options, onSubmit, onCancel }) {
  const isEdit = Boolean(patient);
  const [values, setValues] = useState(() => (patient ? { ...EMPTY, ...patient } : { ...EMPTY, admission_date: todayIST() }));
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);

  const update = (key) => (e) => {
    setValues((v) => ({ ...v, [key]: e.target.value }));
    if (errors[key]) setErrors((errs) => ({ ...errs, [key]: undefined }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    const found = validatePatient(values, options);
    setErrors(found);
    if (Object.keys(found).length) {
      setFormError("Please fix the highlighted fields.");
      return;
    }

    setSaving(true);
    try {
      await onSubmit({
        ...values,
        name: values.name.trim().replace(/\s+/g, " "),
        age: Number(values.age),
      });
    } catch (err) {
      // Show backend field errors next to the matching inputs
      if (err instanceof ApiError) setErrors(err.fieldErrors);
      setFormError(err.message);
      setSaving(false);
    }
  };

  const field = (key, label, input) => (
    <div className={`field ${errors[key] ? "has-error" : ""}`}>
      <label htmlFor={`f-${key}`}>{label}</label>
      {input}
      {errors[key] && (
        <p className="field-error" id={`f-${key}-error`} role="alert">
          {errors[key]}
        </p>
      )}
    </div>
  );

  const aria = (key) => ({
    id: `f-${key}`,
    "aria-invalid": Boolean(errors[key]),
    "aria-describedby": errors[key] ? `f-${key}-error` : undefined,
  });

  const select = (key, label, list) =>
    field(
      key,
      label,
      <select {...aria(key)} value={values[key]} onChange={update(key)}>
        <option value="">Select {label.toLowerCase()}</option>
        {list.map((item) => (
          <option key={item} value={item}>{item}</option>
        ))}
      </select>
    );

  return (
    <form onSubmit={handleSubmit} noValidate className="patient-form">
      {formError && <div className="form-banner" role="alert">{formError}</div>}

      <div className="form-grid">
        <div className="span-2">
          {field(
            "name",
            "Full name",
            <input {...aria("name")} type="text" value={values.name} onChange={update("name")} autoComplete="off" placeholder="e.g. Ravi Kumar" />
          )}
        </div>
        {field(
          "age",
          "Age",
          <input {...aria("age")} type="number" inputMode="numeric" min="0" max="120" step="1" value={values.age} onChange={update("age")} />
        )}
        {select("gender", "Gender", options.genders)}
        {select("ward", "Ward", options.wards)}
        {select("department", "Department", options.departments)}
        {select("doctor", "Doctor", options.doctors)}
        {field(
          "admission_date",
          "Admission date",
          <input {...aria("admission_date")} type="date" max={todayIST()} value={values.admission_date} onChange={update("admission_date")} />
        )}
        {isEdit && select("status", "Status", options.statuses)}
      </div>

      <div className="form-actions">
        <button type="button" className="btn btn-quiet" onClick={onCancel} disabled={saving}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving…" : isEdit ? "Save changes" : "Add patient"}
        </button>
      </div>
    </form>
  );
}
