const dateFormat = new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" });

function formatDate(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return dateFormat.format(new Date(y, m - 1, d));
}

export default function PatientList({ patients, onEdit, onDelete, onDischarge }) {
  return (
    <div className="table-wrap">
      <table className="patients">
        <thead>
          <tr>
            <th scope="col">Patient</th>
            <th scope="col">Age / Gender</th>
            <th scope="col">Ward</th>
            <th scope="col">Department</th>
            <th scope="col">Doctor</th>
            <th scope="col">Admitted on</th>
            <th scope="col">Status</th>
            <th scope="col"><span className="sr-only">Actions</span></th>
          </tr>
        </thead>
        <tbody>
          {patients.map((p) => {
            const discharged = p.status === "Discharged";
            return (
              <tr key={p.id} className={discharged ? "is-discharged" : ""}>
                <td className="cell-patient">
                  <span className="band" aria-hidden="true" />
                  <span className="patient-name">{p.name}</span>
                  <span className="patient-id">ID {String(p.id).padStart(4, "0")}</span>
                </td>
                <td data-label="Age / Gender" className="num">{p.age} yrs, {p.gender}</td>
                <td data-label="Ward">{p.ward}</td>
                <td data-label="Department">{p.department}</td>
                <td data-label="Doctor">{p.doctor}</td>
                <td data-label="Admitted on" className="num">{formatDate(p.admission_date)}</td>
                <td data-label="Status">
                  <span className={`status status-${p.status.toLowerCase()}`}>{p.status}</span>
                </td>
                <td className="cell-actions">
                  {!discharged && (
                    <button type="button" className="btn btn-small btn-outline" onClick={() => onDischarge(p)}>
                      Discharge
                    </button>
                  )}
                  <button type="button" className="btn btn-small btn-quiet" onClick={() => onEdit(p)} aria-label={`Edit ${p.name}`}>
                    Edit
                  </button>
                  <button type="button" className="btn btn-small btn-quiet btn-text-danger" onClick={() => onDelete(p)} aria-label={`Delete ${p.name}`}>
                    Delete
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
