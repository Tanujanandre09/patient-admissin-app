// Frontend validation. Mirrors backend/schemas.py so users see errors
// instantly; the backend still re-checks everything.

const NAME_PATTERN = /^[A-Za-z]+( [A-Za-z]+)*$/;

// "Today" in India time (YYYY-MM-DD), same as the backend's check.
export function todayIST() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
}

export function validatePatient(values, options) {
  const errors = {};
  const name = values.name.trim().replace(/\s+/g, " ");

  if (!name) errors.name = "Name is required";
  else if (!NAME_PATTERN.test(name)) errors.name = "Name can contain letters only (spaces between words are allowed)";
  else if (name.length > 100) errors.name = "Name must be 100 characters or fewer";

  if (values.age === "" || values.age === null) errors.age = "Age is required";
  else {
    const age = Number(values.age);
    if (Number.isNaN(age)) errors.age = "Age must be a number";
    else if (!Number.isInteger(age)) errors.age = "Age must be a whole number";
    else if (age < 0 || age > 120) errors.age = "Age must be between 0 and 120";
  }

  const selects = [
    ["gender", "Gender", options.genders],
    ["ward", "Ward", options.wards],
    ["department", "Department", options.departments],
    ["doctor", "Doctor", options.doctors],
  ];
  selects.forEach(([key, label, list]) => {
    if (!values[key]) errors[key] = `${label} is required`;
    else if (!list.includes(values[key])) errors[key] = `Choose a ${label.toLowerCase()} from the list`;
  });

  if (!values.admission_date) errors.admission_date = "Admission date is required";
  else if (values.admission_date > todayIST()) errors.admission_date = "Admission date cannot be in the future";

  return errors;
}
